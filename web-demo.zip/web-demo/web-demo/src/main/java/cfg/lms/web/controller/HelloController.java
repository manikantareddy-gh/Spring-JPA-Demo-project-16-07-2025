package cfg.lms.web.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

//	@GetMapping("/fetch-employee")
//	public void fetchEmployee(@RequestParam("empid") String empid, @RequestParam("isContractor") String isContractor) {
//		System.out.println(empid + " ---->" + isContractor);
//	}
//
//	@GetMapping("/checkUser/{id}/{name}")
//	public String checkUser(@PathVariable("id") int id, @PathVariable("name") String name) {
//		String isPermanent = "true";
//		if (id == 101 & name.equals("manikanta")) {
//			isPermanent = "false";
//		}
//		return isPermanent;
//	}
//
//	@PostMapping("/login")
//	public String login(@RequestBody UserDTO user) {
//		if (user.getUsername().equalsIgnoreCase(user.getPassword())) {
//			return "login succes";
//		} else {
//			return "login failed";
//		}

//	}

//	@GetMapping("/fetch-employee-data")
//	public List<Employee> fetchEmployeeData() {
//		List<Employee> empList = new ArrayList<>();
//		
//		Employee emp1 = new Employee();
//		emp1.setEmpId(101);
//		emp1.setName("manikanta");
//		emp1.setSalary(1000.00);
//
//		Employee emp2 = new Employee();
//		emp2.setEmpId(102);
//		emp2.setName("durga");
//		emp2.setSalary(2000.00);
//
//		empList.add(emp1);
//		empList.add(emp2);
//
//		return empList;
//	}
	
    
    
}
