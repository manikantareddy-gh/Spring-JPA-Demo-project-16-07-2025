package cfg.lms.web.services.bo;
import lombok.Data;
@Data
public class Employee {
	private int id;
	private String name;
	private double salary;
}
