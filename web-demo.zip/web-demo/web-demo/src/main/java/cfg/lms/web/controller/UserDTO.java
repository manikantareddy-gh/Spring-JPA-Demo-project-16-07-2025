package cfg.lms.web.controller;
import lombok.Data;
@Data
public class UserDTO {
	private String username;
	private String password;

}
